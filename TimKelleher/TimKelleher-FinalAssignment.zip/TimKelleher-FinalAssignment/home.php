<!-- You're probably wondering why I decided not to go with nav arrows for the slider on the home page here

    The answer to that is simple - i found the arrows tacky, and I already knew short hand a basic gallery slideshow jquery plugin for getting the same effect, just without user interaction. 

    the result is the same functionality without any unsightly arrows! I feel it still fits the aesthetic and form of the page.

-->


<!doctype html> 
<html>
	<head>
		<title>Hi, my name is Tim.</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
        <link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900,100italic,300italic,400italic,500italic,700italic,900italic|Open+Sans:400italic,400' rel='stylesheet' type='text/css'>
		<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
	    <link rel="stylesheet" href="styles/normalize.css" type="text/css" media="screen" />
		<link rel="stylesheet" type="text/css" href="css/styles.css">
		<link rel="icon" type="image/x-icon" href="http://favicon-generator.org/favicons/2014-12-09/4e2a0f42a6300494d44bb54912baab15.ico">
        <link rel="shortcut icon" href="http://favicon-generator.org/favicons/2014-12-09/4e2a0f42a6300494d44bb54912baab15.ico" type="image/x-icon">
	<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
	<script src="scripts/main.js"></script>
	</head>
	<body>
		<header id="homeHead">
            <br>
            <br>
            <br>
            <br>
            <br>
			<h1>Hi, My Name is Tim</h1>
            <br>
			<h2>I am a person.</h2>
		</header>
		<nav>
			<span class="fa fa-bars fa-2x" title="menu"></span>
            <a href="home.html"><img src="images/nav-icon.png"></a>
			<ul class="dropdown">
				<li><a href="home.php">Home</a></li>
				<li><a href="about.php">About</a></li>
				<li><a href="portfolio.php">Portfolio</a></li>
			</ul>
		</nav>
		<section id="bar" class="bar">
			<div class="content-wrapper">
                <h2> <u>Timothy Kelleher</u> - Web Developer - Graphic Design - Artist - Nerd</h2>
			</div>
		</section>
    
		<section id="about" class="about">
			<div class="content-wrapper">
				<h2>Who am I? </h2>

				<p> Well, its all just as the header says - I am Timothy Kelleher, and this is my website. I am a Front-end Developer with a primary focus on design and making everything looking as gorgeous as possible. My style is minimalistic, with deep contrasting colours and an absolute love for vector art. I want to do my best to make you a simple, stylish, and straightforward website for whatever your neeeds may be !</p>
                
				<div class="column">
					<h1>&#xf03e;</h1>
					<h3>Graphic Design</h3>
					<p>I have over 6+ Years of both amateur and proffesional graphic design skills, with extensive knowledge of programs such as Photoshop and Illustrator. </p>
				</div>
				<div class="column">
					<h1>&#xf17b;</h1>
					<h3>Mobile Development</h3>
					<p> I have used my free time to develop apps using various mobile API's, such as Androids, as well as Pebble and Razer Nabu - Pet projects that evolved into fully fleshed out ideas. </p>
				</div>
				<div class="column">
					<h1>&#xf121;</h1>
					<h3>Basic Coding</h3>
					<p>I have a working knowledge of HTML, CSS, Javascript, Jquery, PHP, and etc. I even made this whole website from scratch, how about that? </p>
				</div>
				<div class="column">
					<h1>&#xf0c0;</h1>
					<h3>Good Team Worker</h3>
					<p>I find myself very at home when working alongside others in my feild on one major project. I am a solid and motivated individual who prides themselves in being able to fill the gaps in any team setting. </p>		
				</div>


			</div>
		</section>

		<section id="projects" class="projects">
			<div class="content-wrapper">
				<h2>Noteable Projects</h2>
                <p class="desc">Here are some cherry-picked pieces from my portfolio that I think really captures my style and who I am as a designer and a developer</p>
				<div class="column">
					<img src="images/project-1.jpg">
					<h3>My First Spa</h3>
					<p>Basic logo design for a fellow start-up</p>
				</div>
				<div class="column">
					<img src="images/project-2.jpg">
					<h3>BATL App</h3>
					<p>The official axe throwing league app for Android</p>
				</div>
				<div class="column">
					<img src="images/project-3.jpg">
					<h3>The Wanderer</h3>
					<p>A basic landing page for a magician friend of mine</p>
				</div>
				<div class="column">
					<img src="images/project-4.jpg">
					<h3>Garfield The Movie The Band</h3>
					<p>An indie hardcore punk band with a fresh logo from yours truly</p>		
				</div>
			</div>			
		</section>


		<footer>
			<p>2014 &#169; Timothy Kelleher </p>
		</footer>

		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<script>
			$(document).ready(function(){
				$(".fa-bars").on("click", function(){
					$(".dropdown").toggleClass("open");
				});
			});
		</script>
	</body>
</html>