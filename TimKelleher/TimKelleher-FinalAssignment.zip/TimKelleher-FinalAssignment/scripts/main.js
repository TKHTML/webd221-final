
$(function() {
  var header = $('#homeHead');
  var backgrounds = ['url(images/headerbg-1.jpg)',
  'url(images/headerbg-2.jpg)',
  'url(images/headerbg-3.jpg)',
  'url(images/headerbg-4.jpg)',];
var current = 0;

function nextBackground() {
  header.css(
   'background',
    backgrounds[current = ++current % backgrounds.length]
 );

 setTimeout(nextBackground, 7500);
 }
 setTimeout(nextBackground, 7500);
   header.css('background', backgrounds[0]);
 });

var previousScroll = 0,
    headerOrgOffset = $('nav').height();

$('nav').height($('nav').height());

$(window).scroll(function () {
    var currentScroll = $(this).scrollTop();
    if (currentScroll > headerOrgOffset) {
        if (currentScroll > previousScroll) {
            $('nav').slideUp();
        } else {
            $('nav').slideDown();
        }
    } 
    previousScroll = currentScroll;
});