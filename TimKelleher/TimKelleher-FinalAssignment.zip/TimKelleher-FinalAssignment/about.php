<!-- I found it kinda interesting, make a "Who we are page" about just me. -->


<!doctype html> 
<html>
	<head>
		<title>A little bit about me.</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
        <link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900,100italic,300italic,400italic,500italic,700italic,900italic|Open+Sans:400italic,400' rel='stylesheet' type='text/css'>
		<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
	    <link rel="stylesheet" href="styles/normalize.css" type="text/css" media="screen" />
		<link rel="stylesheet" type="text/css" href="css/styles.css">
		<link rel="icon" type="image/x-icon" href="http://favicon-generator.org/favicons/2014-12-09/4e2a0f42a6300494d44bb54912baab15.ico">
        <link rel="shortcut icon" href="http://favicon-generator.org/favicons/2014-12-09/4e2a0f42a6300494d44bb54912baab15.ico" type="image/x-icon">
	<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
	<script src="scripts/main.js"></script>
	</head>
	<body id="aboutPg">
		<header id="aboutHead">
            <br>
            <br>
			<h1>About <b>Me</b></h1>
            <p> I figure if you're looking at this website - chances are you want to hire me,<br>so maybe you'd like to know a bit about my background?</p>
		</header>
		<nav>
			<span class="fa fa-bars fa-2x" title="menu"></span>
            <a href="home.html"><img src="images/nav-icon.png"></a>
			<ul class="dropdown">
				<li><a href="home.php">Home</a></li>
				<li><a href="about.php">About</a></li>
				<li><a href="portfolio.php">Portfolio</a></li>
			</ul>
		</nav>

    
		<section id="story" class="story">
			<div class="content-wrapper">
				<h2>My Story</h2>

				<p> I spent much of my young aduly life interested in computers, science fiction, technology, and gaming. All of it has culminated into my love for web development and digital arts. I spent 5+ years making art using my own free time and school computer labs. Humber college had also accepted my application for web design and interactive media, so I suppose I have that experience under my belt as well. All of my work is freelance, and if you ask me nicely enough, I might even do it for free.</p> <!-- oor you could be like my brother and play the family card - I don't need "portfolio pieces" I need money. /rant -->
               
			</div>
		</section>

		<section id="skills" class="skills">
			<div class="content-wrapper">
				<h2>My Skills</h2>
 
				<div class="column">
					<img src="images/circle-1.png">
					<h3>Adobe Illustrator</h3>
                    <p> 5+ years</p>
					<p> I spent a lot of time with this program in hish school, time I took to draw many silly and awful things and posting them to deviant art, but it has helped me hone my skills and I can eaily make a vector based graphics in a pinch</p>
				</div>
				<div class="column">
					<img src="images/circle-2.png">
					<h3>Photoshop</h3>
                    <p> 6+ years</p>
					<p> From putting penguins on the moon (literally the first ever things I "shopped" back in the day) to creating wireframes; I certianly have come a long way from my humble beginnings</p>
				</div>
				<div class="column">
					<img src="images/circle-3.png">
					<h3>Tablet + Pen Work</h3>
                    <p> 4+ years</p>
					<p>I prefer to hand-draw 90% of the time, so investing in a Wacom Bamboo made sense - tricky to work with, but if you ever wanted to emulate a hand drawn style there aren't any better options </p>
				</div>
				<div class="column">
					<img src="images/circle-4.png">
					<h3>HTML, CSS, etc</h3>
                    <p>2+ years</p>
					<p>Coding is hard, and I spent the good amount of my college time struggling with it. But if you give me enough time, I can eventually persevere and make something unique and interesting </p>		
				</div>
                
			</div>			
		</section>

		<section id="mission" class="mission">
			<div class="content-wrapper">
				<h2>My Mission</h2>
                
					<p> I've come a long way from just an awkward teenager who liked to make 'edgy' art and put it online, now I've become an eager designer and developer who really just wants to break out in this industry and go places. I want to be a key part of a team, a lead designer who can code when the situation calls for it. I want to be a major, important team player in a bright and happy office environment.<br><br>
Realisticly, though? I'd just like a job that can afford me my own apartment so I don't' have to mooch of mom anymore.</p>

                <img src="images/mission-img.png">
                
			</div>			
		</section>
        

		<footer>
			<p>2014 &#169; Timothy Kelleher </p>
		</footer>

		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<script>
			$(document).ready(function(){
				$(".fa-bars").on("click", function(){
					$(".dropdown").toggleClass("open");
				});
			});
		</script>
	</body>
</html>