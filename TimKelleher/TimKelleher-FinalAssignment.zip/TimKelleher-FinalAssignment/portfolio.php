<!-- fun fact - those thumbnail images, and the ones on my home page, are literally things I made! apart from the BATL app, thats a WIP I'm doing in my free time, but everything else is real! all original content! even that picture of me in the about page! -->


<!doctype html> 
<html>
	<head>
		<title>My Portfolio</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
        <link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900,100italic,300italic,400italic,500italic,700italic,900italic|Open+Sans:400italic,400' rel='stylesheet' type='text/css'>
		<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
	    <link rel="stylesheet" href="styles/normalize.css" type="text/css" media="screen" />
		<link rel="stylesheet" type="text/css" href="css/styles.css">
		<link rel="icon" type="image/x-icon" href="http://favicon-generator.org/favicons/2014-12-09/4e2a0f42a6300494d44bb54912baab15.ico">
        <link rel="shortcut icon" href="http://favicon-generator.org/favicons/2014-12-09/4e2a0f42a6300494d44bb54912baab15.ico" type="image/x-icon">
	<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
	<script src="scripts/main.js"></script>
	</head>
	<body id="portPg">
		<header id="portHead">
            <br>
            <br>
			<h1>My <b>Portfolio</b></h1>
            <p> A small collection of things I've worked on over the years</p>
		</header>
		<nav>
			<span class="fa fa-bars fa-2x" title="menu"></span>
            <a href="home.html"><img src="images/nav-icon.png"></a>
			<ul class="dropdown">
				<li><a href="home.php">Home</a></li>
				<li><a href="about.php">About</a></li>
				<li><a href="portfolio.php">Portfolio</a></li>
			</ul>
		</nav>

    
		<section id="artTT" class="artTT">
			<div class="content-wrapper">
				<h2>My Artwork</h2>

				<p> Here is a small collection of some of my favorite pieces that I have worked on over the years. My art style can be decribed as distinct, minimal, and modern. </p>
               
			</div>
		</section>

		<section id="art" class="art">
			<div class="content-wrapper">
 
				<div class="column">
					<img src="images/art-1.jpg">
				</div>
                
				<div class="column">
					<img src="images/art-2.jpg">
				</div>
                
				<div class="column">
					<img src="images/art-3.jpg">
				</div>
                
				<div class="column">
					<img src="images/art-4.jpg">	
				</div>

				<div class="column">
					<img src="images/art-5.jpg">
				</div>
                
				<div class="column">
					<img src="images/art-6.jpg">
				</div>
                
				<div class="column">
					<img src="images/art-7.jpg">
				</div>
                
				<div class="column">
					<img src="images/art-8.jpg">	
				</div>
                
				<div class="column">
					<img src="images/art-9.jpg">
				</div>
                
			</div>			
		</section>

        

		<footer>
			<p>2014 &#169; Timothy Kelleher </p>
		</footer>

		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<script>
			$(document).ready(function(){
				$(".fa-bars").on("click", function(){
					$(".dropdown").toggleClass("open");
				});
			});
		</script>
	</body>
</html>